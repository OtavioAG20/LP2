﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAtv1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            for (int i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}° dado: ", "Entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
            }
                Array.Reverse(vetor);//Aqui vai ocorrer a inversão
                auxiliar = "";// Aqui está limpando os números que foram digitados no InputBox
                foreach (int x in vetor)
                    auxiliar += x + "\n";
                MessageBox.Show(auxiliar);
           // auxiliar = "";
           // auxiliar = string.Join("\n", vetor);
           //MessageBox.Show(auxiliar);


        }

        private void btnAtv2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais" };
            string auxiliar = "";
            lista.Remove(7);
            
            for(int c = 0; c < lista; c++)
            auxiliar =string.Join(", ", lista);
            MessageBox.Show(auxiliar);
        }

        private void btnAtv3_Click(object sender, EventArgs e)
        {
            Double[,] notas = new double[20, 3];
        }
    }
}
