﻿namespace PMatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAtv1 = new System.Windows.Forms.Button();
            this.btnAtv2 = new System.Windows.Forms.Button();
            this.btnAtv3 = new System.Windows.Forms.Button();
            this.btnAtv4 = new System.Windows.Forms.Button();
            this.btnAtv5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAtv1
            // 
            this.btnAtv1.Location = new System.Drawing.Point(155, 70);
            this.btnAtv1.Name = "btnAtv1";
            this.btnAtv1.Size = new System.Drawing.Size(105, 59);
            this.btnAtv1.TabIndex = 0;
            this.btnAtv1.Text = "Atividade 1";
            this.btnAtv1.UseVisualStyleBackColor = true;
            this.btnAtv1.Click += new System.EventHandler(this.btnAtv1_Click);
            // 
            // btnAtv2
            // 
            this.btnAtv2.Location = new System.Drawing.Point(290, 70);
            this.btnAtv2.Name = "btnAtv2";
            this.btnAtv2.Size = new System.Drawing.Size(98, 59);
            this.btnAtv2.TabIndex = 1;
            this.btnAtv2.Text = "Atividade 2";
            this.btnAtv2.UseVisualStyleBackColor = true;
            this.btnAtv2.Click += new System.EventHandler(this.btnAtv2_Click);
            // 
            // btnAtv3
            // 
            this.btnAtv3.Location = new System.Drawing.Point(155, 135);
            this.btnAtv3.Name = "btnAtv3";
            this.btnAtv3.Size = new System.Drawing.Size(105, 70);
            this.btnAtv3.TabIndex = 2;
            this.btnAtv3.Text = "Atividade 3";
            this.btnAtv3.UseVisualStyleBackColor = true;
            this.btnAtv3.Click += new System.EventHandler(this.btnAtv3_Click);
            // 
            // btnAtv4
            // 
            this.btnAtv4.Location = new System.Drawing.Point(290, 135);
            this.btnAtv4.Name = "btnAtv4";
            this.btnAtv4.Size = new System.Drawing.Size(98, 70);
            this.btnAtv4.TabIndex = 3;
            this.btnAtv4.Text = "Atividade 4";
            this.btnAtv4.UseVisualStyleBackColor = true;
            // 
            // btnAtv5
            // 
            this.btnAtv5.Location = new System.Drawing.Point(218, 225);
            this.btnAtv5.Name = "btnAtv5";
            this.btnAtv5.Size = new System.Drawing.Size(98, 70);
            this.btnAtv5.TabIndex = 4;
            this.btnAtv5.Text = "Atividade 5";
            this.btnAtv5.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnAtv5);
            this.Controls.Add(this.btnAtv4);
            this.Controls.Add(this.btnAtv3);
            this.Controls.Add(this.btnAtv2);
            this.Controls.Add(this.btnAtv1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAtv1;
        private System.Windows.Forms.Button btnAtv2;
        private System.Windows.Forms.Button btnAtv3;
        private System.Windows.Forms.Button btnAtv4;
        private System.Windows.Forms.Button btnAtv5;
    }
}

