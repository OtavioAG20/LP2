﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1: Form
    {
        double a, b, c;
        public Form1()
        {
            InitializeComponent();
        }


        private void textA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textA.Text, out a) || a < 0)
            {
                MessageBox.Show("Valor inválido! Favor verificar se o número é negativo ou se tem letra.");
                textA.Focus();
            }
        }


        private void textB_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(textB.Text, out b) || b < 0)
            {
                MessageBox.Show("Valor inválido! Favor verificar se o número é negativo ou se tem letra.");
                textB.Focus();
            }
        }


        private void textC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textC.Text, out c) || c < 0)
            {
                MessageBox.Show("Valor inválido! Favor verificar se o número é negativo ou se tem letra.");
                textC.Focus();
            }
                
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            textA.Clear();
            textB.Clear();
            textC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if(((Math.Abs(b - c) < a) && (a < b +c)) && ((Math.Abs(a -c)<b) && (b < a + c)) &&((Math.Abs(a-b)<c) && c < a + b))
            {
                MessageBox.Show("Através dos valores fornecidos, eles podem formar um triângulo!");
                if (a == b && b == c)
                    MessageBox.Show("Este triângulo é equilátero!");
                else
                    if (a == b || b == c || a == c)
                    MessageBox.Show("Este triângulo é isósceles!");
                else
                    MessageBox.Show("Este triângulo é escaleno!");
             }
            else
                MessageBox.Show("Atravès dos valores fornecidos eles não podem formar um trîângulo");
        }
        
    }
}
