namespace calculoIMC
{
    public partial class Form1 : Form
    {
        double peso, altura, IMC;
        public Form1()
        {
            InitializeComponent();
        }

        private void maskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(maskbxPeso.Text, out peso))
            {
                MessageBox.Show("Peso inv�lido!");
                maskbxPeso.Focus();
            }
        }

        private void maskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(maskbxAltura.Text, out altura))
            {
                MessageBox.Show("Altura inv�lida!");
                maskbxAltura.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            IMC = peso / Math.Pow(altura, 2);
            txtIMC.Text = IMC.ToString("N2");
            IMC = Math.Round(IMC, 1);
            if (IMC < 18.5)
                MessageBox.Show("A pessoa est� classificada com IMC de magreza!" + IMC);
            else
                if (IMC >= 18.5 && IMC <= 24.9)
                MessageBox.Show("A pessoa est� classificada com IMC normal!" + IMC);
            else
                    if (IMC >= 25 && IMC <= 29.9)
                MessageBox.Show("A pessoa est� classificada com IMC de sobrepeso!" + IMC);
            else
                        if (IMC >= 30 && IMC <= 39.9)
                MessageBox.Show("A pessoa est� classificada com o IMC de obesidade!" + IMC);
            else
                MessageBox.Show("A pessoa est� classificada com o IMC de obesidade grave!" + IMC);

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            maskbxAltura.Clear();
            maskbxPeso.Clear();
            txtIMC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
