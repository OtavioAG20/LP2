﻿namespace calculoIMC
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPeso = new Label();
            lblAltura = new Label();
            lblIMC = new Label();
            maskbxPeso = new MaskedTextBox();
            maskbxAltura = new MaskedTextBox();
            txtIMC = new TextBox();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            SuspendLayout();
            // 
            // lblPeso
            // 
            lblPeso.AutoSize = true;
            lblPeso.Location = new Point(33, 25);
            lblPeso.Name = "lblPeso";
            lblPeso.Size = new Size(32, 15);
            lblPeso.TabIndex = 0;
            lblPeso.Text = "Peso";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Location = new Point(29, 63);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(39, 15);
            lblAltura.TabIndex = 1;
            lblAltura.Text = "Altura";
            // 
            // lblIMC
            // 
            lblIMC.AutoSize = true;
            lblIMC.Location = new Point(34, 97);
            lblIMC.Name = "lblIMC";
            lblIMC.Size = new Size(29, 15);
            lblIMC.TabIndex = 2;
            lblIMC.Text = "IMC";
            // 
            // maskbxPeso
            // 
            maskbxPeso.Location = new Point(71, 22);
            maskbxPeso.Mask = "900.00";
            maskbxPeso.Name = "maskbxPeso";
            maskbxPeso.Size = new Size(100, 23);
            maskbxPeso.TabIndex = 3;
            maskbxPeso.Validated += maskbxPeso_Validated;
            // 
            // maskbxAltura
            // 
            maskbxAltura.Location = new Point(71, 60);
            maskbxAltura.Mask = "0.00";
            maskbxAltura.Name = "maskbxAltura";
            maskbxAltura.Size = new Size(100, 23);
            maskbxAltura.TabIndex = 4;
            maskbxAltura.Validated += maskbxAltura_Validated;
            // 
            // txtIMC
            // 
            txtIMC.Enabled = false;
            txtIMC.Location = new Point(69, 94);
            txtIMC.Name = "txtIMC";
            txtIMC.Size = new Size(100, 23);
            txtIMC.TabIndex = 5;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(292, 191);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(125, 70);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(156, 279);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(121, 80);
            btnLimpar.TabIndex = 7;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(420, 279);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(138, 77);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(txtIMC);
            Controls.Add(maskbxAltura);
            Controls.Add(maskbxPeso);
            Controls.Add(lblIMC);
            Controls.Add(lblAltura);
            Controls.Add(lblPeso);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPeso;
        private Label lblAltura;
        private Label lblIMC;
        private MaskedTextBox maskbxPeso;
        private MaskedTextBox maskbxAltura;
        private TextBox txtIMC;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnSair;
    }
}
