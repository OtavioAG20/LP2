﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pratica_LP2_Aula6
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }
        

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int textomaximo = 100;
            int Contadora = 0;
            if (richtxtCaixa.Text.Length > textomaximo)
            {
                MessageBox.Show($"Limite de {textomaximo} de caracteres atingido!");
                richtxtCaixa.SelectionStart = textomaximo; 
            }
            else
            {
                for( int i = 0; i < richtxtCaixa.TextLength; i++ )
                {
                    if (char.IsWhiteSpace(richtxtCaixa.Text[i]))
                    Contadora = Contadora + 1;

                }
                MessageBox.Show($"A quantidade de espaços em branco é {Contadora}");
            }
        }

        private void btnQtdeR_Click(object sender, EventArgs e)
        {
            
        }
    }
}
