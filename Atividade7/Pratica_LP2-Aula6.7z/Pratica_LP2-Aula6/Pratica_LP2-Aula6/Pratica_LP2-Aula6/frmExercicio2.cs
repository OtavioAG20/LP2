﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pratica_LP2_Aula6
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float divisor = 2, numero;
            float valor = 0;
            if (float.TryParse(txtNumero.Text, out numero))
                {
                if(numero <=0)
                {
                    MessageBox.Show("Número inválido");
                    txtNumero.Focus();
                    txtNumero.Clear();
                }
                if (numero == 1)
                    valor = 1 + (1 / numero);
                if (numero == 2)
                    valor = 1 + (1 / numero);
                if (numero > 2)
                {
                    for (divisor = 2; divisor <= numero; divisor++)
                    {
                        if (divisor == 2)
                            valor = 1 + (1 / divisor);
                        if (divisor > 2 && divisor < numero)
                            valor = valor + (1 / divisor);
                        if (divisor == numero)
                            valor = valor + (1 / divisor);

                    }
                }
                MessageBox.Show($"Esse é o valor de H: {valor}");
            }
            else
            {
                MessageBox.Show("Número inválido");
                txtNumero.Focus();
                txtNumero.Clear();
            }


        }
    }
}
