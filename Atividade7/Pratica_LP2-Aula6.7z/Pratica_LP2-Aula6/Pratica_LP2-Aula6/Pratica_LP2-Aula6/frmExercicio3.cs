﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pratica_LP2_Aula6
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void txtPalindromo_TextChanged(object sender, EventArgs e)
        {
            txtPalindromo.MaxLength = 50;

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string texto = txtPalindromo.Text.Replace(" ", "");
            texto = texto.ToLower();
            char[] letras = texto.ToCharArray();
            Array.Reverse(letras);
            string textoInvertido = new string(letras);
            if (String.Compare(texto, textoInvertido)==0)
            {
                MessageBox.Show("É um palíndromo");
            }
            else
            {
                MessageBox.Show("Não é um palíndromo");
            }
        }
    }
}
