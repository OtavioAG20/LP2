﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pratica_LP2_Aula6
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }
        

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int Contadora = 0;  
            {
                for( int i = 0; i < richtxtCaixa.TextLength; i++ )
                {
                    if (char.IsWhiteSpace(richtxtCaixa.Text[i]))
                    Contadora = Contadora + 1;

                }
                MessageBox.Show($"A quantidade de espaços em branco é {Contadora}");
            }
        }

        private void btnQtdeR_Click(object sender, EventArgs e)
        {
            string texto = richtxtCaixa.Text;
            int cont = 0;
            foreach (char letra in texto)
            {
                if (letra == 'r' || letra == 'R')
                    cont = cont + 1;
            }
            MessageBox.Show($"A quantidade de letras R é {cont}");
        }

        private void btnPares_Click(object sender, EventArgs e)
        {
            int cont = 0, repetidas=0;
            while(cont < richtxtCaixa.Text.Length)
            {
                richtxtCaixa.Text = richtxtCaixa.Text.ToLower();
                if (cont < richtxtCaixa.Text.Length - 1 && richtxtCaixa.Text[cont] == richtxtCaixa.Text[cont + 1]) // esse -1 é para não dar erro de index, ou seja, de acesso a posição da string porque sem o -1 na última letra ele vai tentar acessar a próxima letra que não existe
                {
                    repetidas = repetidas + 1;
                }
                cont++;
            }
            MessageBox.Show($"A quantidade de letras pares é: {repetidas}");
        }

        private void richtxtCaixa_TextChanged(object sender, EventArgs e)
        {
            richtxtCaixa.MaxLength = 100;
        }
    }
}
