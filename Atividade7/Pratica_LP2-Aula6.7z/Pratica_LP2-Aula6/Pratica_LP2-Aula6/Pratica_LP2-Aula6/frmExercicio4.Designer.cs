﻿namespace Pratica_LP2_Aula6
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMat = new System.Windows.Forms.TextBox();
            this.txtProducao = new System.Windows.Forms.TextBox();
            this.txtGrati = new System.Windows.Forms.TextBox();
            this.txtSal = new System.Windows.Forms.TextBox();
            this.btnSalario = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 33);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 76);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Matrícula";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(43, 123);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Produção";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(43, 160);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Salário";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(43, 198);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Gratificação";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(97, 30);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(132, 22);
            this.txtNome.TabIndex = 5;
            // 
            // txtMat
            // 
            this.txtMat.Location = new System.Drawing.Point(120, 76);
            this.txtMat.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMat.Name = "txtMat";
            this.txtMat.Size = new System.Drawing.Size(132, 22);
            this.txtMat.TabIndex = 6;
            // 
            // txtProducao
            // 
            this.txtProducao.Location = new System.Drawing.Point(121, 119);
            this.txtProducao.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtProducao.Name = "txtProducao";
            this.txtProducao.Size = new System.Drawing.Size(132, 22);
            this.txtProducao.TabIndex = 7;
            // 
            // txtGrati
            // 
            this.txtGrati.Location = new System.Drawing.Point(136, 198);
            this.txtGrati.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtGrati.Name = "txtGrati";
            this.txtGrati.Size = new System.Drawing.Size(132, 22);
            this.txtGrati.TabIndex = 8;
            // 
            // txtSal
            // 
            this.txtSal.Location = new System.Drawing.Point(103, 156);
            this.txtSal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSal.Name = "txtSal";
            this.txtSal.Size = new System.Drawing.Size(132, 22);
            this.txtSal.TabIndex = 9;
            // 
            // btnSalario
            // 
            this.btnSalario.Location = new System.Drawing.Point(471, 76);
            this.btnSalario.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSalario.Name = "btnSalario";
            this.btnSalario.Size = new System.Drawing.Size(256, 81);
            this.btnSalario.TabIndex = 10;
            this.btnSalario.Text = "Salário Bruto";
            this.btnSalario.UseVisualStyleBackColor = true;
            this.btnSalario.Click += new System.EventHandler(this.btnSalario_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btnSalario);
            this.Controls.Add(this.txtSal);
            this.Controls.Add(this.txtGrati);
            this.Controls.Add(this.txtProducao);
            this.Controls.Add(this.txtMat);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMat;
        private System.Windows.Forms.TextBox txtProducao;
        private System.Windows.Forms.TextBox txtGrati;
        private System.Windows.Forms.TextBox txtSal;
        private System.Windows.Forms.Button btnSalario;
    }
}