﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pratica_LP2_Aula6
{
    public partial class frmExercicio4 : Form
    {
        int producao, matricula;
        float salario, salariobruto, gratificacao, b, c, d;
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnSalario_Click(object sender, EventArgs e)
        {
            if(!int.TryParse(txtMat.Text, out matricula))
            {
                MessageBox.Show("Matrícula inválida");
                txtMat.Focus();
                txtMat.Clear();
            }
            if (!float.TryParse(txtSal.Text, out salario))
            {
                MessageBox.Show("Salário inválido");
                txtSal.Focus();
                txtSal.Clear();
            }   
            if(!int.TryParse(txtProducao.Text, out producao))
            {
                MessageBox.Show("Produção inválida");
                txtProducao.Focus();
                txtProducao.Clear();
            }
            if(!float.TryParse(txtGrati.Text, out gratificacao))
            {
                MessageBox.Show("Gratificação inválida");
                txtGrati.Focus();
                txtGrati.Clear();
            }
            if (producao >= 100)
                b = 1;
            else 
                b = 0;
            if(producao >= 120)
                c = 1;
            else
                c = 0;
            if (producao >= 150)
                d = 1;
            else
                d = 0;
            salariobruto = (float)(salario + salario* (0.05 * b + 0.1 * c + 0.1 * d));
            if (salariobruto > 7000)
            {
                if (gratificacao > 0 && producao >= 150)
                {
                    salariobruto = salariobruto + gratificacao;
                    MessageBox.Show($"O salário bruto do funcionário é de {salariobruto}");
                }   
                else
                    MessageBox.Show($"O salário do funcionário ultrapassou 7000, porém ele não cumpriu os requisitos, então o salário dele será de 7000!");
            }
            else
            {
                salariobruto = salariobruto + gratificacao;
                MessageBox.Show($"Salário bruto do funcionário é de {salariobruto}");
            }
               

        }
    }
}
