﻿namespace Pratica_LP2_Aula6
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richtxtCaixa = new System.Windows.Forms.RichTextBox();
            this.btnBranco = new System.Windows.Forms.Button();
            this.btnQtdeR = new System.Windows.Forms.Button();
            this.btnPares = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richtxtCaixa
            // 
            this.richtxtCaixa.Location = new System.Drawing.Point(100, 64);
            this.richtxtCaixa.Name = "richtxtCaixa";
            this.richtxtCaixa.Size = new System.Drawing.Size(322, 126);
            this.richtxtCaixa.TabIndex = 0;
            this.richtxtCaixa.Text = "";
            // 
            // btnBranco
            // 
            this.btnBranco.Location = new System.Drawing.Point(63, 266);
            this.btnBranco.Name = "btnBranco";
            this.btnBranco.Size = new System.Drawing.Size(104, 53);
            this.btnBranco.TabIndex = 1;
            this.btnBranco.Text = "Quantidade de espaçoes em branco";
            this.btnBranco.UseVisualStyleBackColor = true;
            this.btnBranco.Click += new System.EventHandler(this.btnBranco_Click);
            // 
            // btnQtdeR
            // 
            this.btnQtdeR.Location = new System.Drawing.Point(202, 266);
            this.btnQtdeR.Name = "btnQtdeR";
            this.btnQtdeR.Size = new System.Drawing.Size(100, 53);
            this.btnQtdeR.TabIndex = 2;
            this.btnQtdeR.Text = "O número de vezes que aparece R";
            this.btnQtdeR.UseVisualStyleBackColor = true;
            this.btnQtdeR.Click += new System.EventHandler(this.btnQtdeR_Click);
            // 
            // btnPares
            // 
            this.btnPares.Location = new System.Drawing.Point(330, 266);
            this.btnPares.Name = "btnPares";
            this.btnPares.Size = new System.Drawing.Size(104, 53);
            this.btnPares.TabIndex = 3;
            this.btnPares.Text = "Número de pares de letras";
            this.btnPares.UseVisualStyleBackColor = true;
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnPares);
            this.Controls.Add(this.btnQtdeR);
            this.Controls.Add(this.btnBranco);
            this.Controls.Add(this.richtxtCaixa);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richtxtCaixa;
        private System.Windows.Forms.Button btnBranco;
        private System.Windows.Forms.Button btnQtdeR;
        private System.Windows.Forms.Button btnPares;
    }
}