using System.Windows.Forms.VisualStyles;

namespace pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("N�mero inv�lido!");
                txtNumero1.Focus();
            }
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero2.Text, out numero2))
            {
                MessageBox.Show("N�mero inv�lido!");
                txtNumero2.Focus();
            }
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString();
            MessageBox.Show("O resultado da soma �: " + resultado);
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text= resultado.ToString();
            MessageBox.Show("O resultado da subtra��o �: " + resultado);
        }

        private void btnMulti_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString();
            MessageBox.Show("O resultado da multiplica��o �: " + resultado);
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
                MessageBox.Show("O n�mero 2 � inv�lido para a divis�o!");

            else
            {
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString();
                MessageBox.Show("O resultado da divis�o �: " + resultado);
            }





        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtNumero2.Clear();
            txtNumero1.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        
    }
}
