﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void btnInsMenslista_Click(object sender, EventArgs e)//Não se cria objeto de classe abstrata
        {
            Mensalista objMensalista = new Mensalista();

            objMensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEnt.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txtSalario.Text);
            objMensalista.NomeEmpregado = Convert.ToString(txtNome.Text);
            MessageBox.Show("Nome=" + objMensalista.NomeEmpregado + "\n" + "Tempo Trabalho:" + objMensalista.TempoTrabalho() + "\n" + "Salário Final" + objMensalista.SalarioBruto().ToString("N2"));
        }

        private void btnInsMensalistapp_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista(Convert.ToInt32(txtMatricula.Text), txtNome.Text, Convert.ToDateTime(txtDataEnt.Text), Convert.ToDouble(txtSalario.Text));
            MessageBox.Show("Nome=" + objMensalista.NomeEmpregado + "\n" + "Tempo Trabalho:" + objMensalista.TempoTrabalho() + "\n" + "Salário Final" + objMensalista.SalarioBruto().ToString("N2"));


        }
    }
}
