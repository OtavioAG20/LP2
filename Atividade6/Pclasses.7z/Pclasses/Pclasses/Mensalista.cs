﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    internal class Mensalista : Empregada //Esses : significa q o Mensalista é uma subclasse de Empregada 
    {
        public Double SalarioMensal { get; set; }

        public override double SalarioBruto()// Aqui está sobreescrevendo o salario bruto da classe empregada
        {
            return SalarioMensal;
        }
    
     public Mensalista()
        {
            System.Windows.Forms.MessageBox.Show("Aqui é mensalista");
        }
        public Mensalista(int matx, string nomex, DateTime datax, double salx)
        {
            this.NomeEmpregado = nomex;
            this.Matricula = matx;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salx;
        }
    }
 }
