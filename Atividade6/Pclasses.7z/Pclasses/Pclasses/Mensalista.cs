﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    internal class Mensalista : Empregada //Esses : significa q o Mensalista é uma subclasse de Empregada 
    {
        public Double SalarioMensal { get; set; }
    
    public override double SalarioBruto()// Aqui está sobreescrevendo o salario bruto da classe empregada
        {
            return SalarioMensal;
        }
    } 
}
