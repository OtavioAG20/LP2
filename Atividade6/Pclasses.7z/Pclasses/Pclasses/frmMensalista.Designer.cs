﻿namespace Pclasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblMatricula = new Label();
            lblNome = new Label();
            lblSalMensal = new Label();
            lblDataEnt = new Label();
            txtMatricula = new TextBox();
            txtNome = new TextBox();
            txtSalario = new TextBox();
            txtDataEnt = new TextBox();
            btnInsMenslista = new Button();
            btnInsMensalistapp = new Button();
            SuspendLayout();
            // 
            // lblMatricula
            // 
            lblMatricula.AutoSize = true;
            lblMatricula.Location = new Point(50, 35);
            lblMatricula.Name = "lblMatricula";
            lblMatricula.Size = new Size(57, 15);
            lblMatricula.TabIndex = 0;
            lblMatricula.Text = "Matrícula";
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(50, 67);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(40, 15);
            lblNome.TabIndex = 1;
            lblNome.Text = "Nome";
            // 
            // lblSalMensal
            // 
            lblSalMensal.AutoSize = true;
            lblSalMensal.Location = new Point(50, 97);
            lblSalMensal.Name = "lblSalMensal";
            lblSalMensal.Size = new Size(83, 15);
            lblSalMensal.TabIndex = 2;
            lblSalMensal.Text = "Salário Mensal";
            // 
            // lblDataEnt
            // 
            lblDataEnt.AutoSize = true;
            lblDataEnt.Location = new Point(50, 125);
            lblDataEnt.Name = "lblDataEnt";
            lblDataEnt.Size = new Size(138, 15);
            lblDataEnt.TabIndex = 3;
            lblDataEnt.Text = "Data Entrada da Empresa";
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(113, 35);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(100, 23);
            txtMatricula.TabIndex = 4;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(96, 64);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(339, 23);
            txtNome.TabIndex = 5;
            // 
            // txtSalario
            // 
            txtSalario.Location = new Point(139, 94);
            txtSalario.Name = "txtSalario";
            txtSalario.Size = new Size(155, 23);
            txtSalario.TabIndex = 6;
            // 
            // txtDataEnt
            // 
            txtDataEnt.Location = new Point(194, 126);
            txtDataEnt.Name = "txtDataEnt";
            txtDataEnt.Size = new Size(147, 23);
            txtDataEnt.TabIndex = 7;
            // 
            // btnInsMenslista
            // 
            btnInsMenslista.Location = new Point(119, 211);
            btnInsMenslista.Name = "btnInsMenslista";
            btnInsMenslista.Size = new Size(194, 55);
            btnInsMenslista.TabIndex = 8;
            btnInsMenslista.Text = "Instanciar Mensalista";
            btnInsMenslista.UseVisualStyleBackColor = true;
            btnInsMenslista.Click += btnInsMenslista_Click;
            // 
            // btnInsMensalistapp
            // 
            btnInsMensalistapp.Location = new Point(379, 211);
            btnInsMensalistapp.Name = "btnInsMensalistapp";
            btnInsMensalistapp.Size = new Size(201, 62);
            btnInsMensalistapp.TabIndex = 9;
            btnInsMensalistapp.Text = "Instanciar Mensalista passando parâmetro";
            btnInsMensalistapp.UseVisualStyleBackColor = true;
            // 
            // frmMensalista
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnInsMensalistapp);
            Controls.Add(btnInsMenslista);
            Controls.Add(txtDataEnt);
            Controls.Add(txtSalario);
            Controls.Add(txtNome);
            Controls.Add(txtMatricula);
            Controls.Add(lblDataEnt);
            Controls.Add(lblSalMensal);
            Controls.Add(lblNome);
            Controls.Add(lblMatricula);
            Name = "frmMensalista";
            Text = "frmMensalista";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblMatricula;
        private Label lblNome;
        private Label lblSalMensal;
        private Label lblDataEnt;
        private TextBox txtMatricula;
        private TextBox txtNome;
        private TextBox txtSalario;
        private TextBox txtDataEnt;
        private Button btnInsMenslista;
        private Button btnInsMensalistapp;
    }
}