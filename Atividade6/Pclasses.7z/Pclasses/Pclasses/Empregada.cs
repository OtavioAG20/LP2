﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.Marshalling;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    abstract internal class Empregada
    {
        private int matricula;
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        public int Matricula
        {
            get { return matricula; }
            set { matricula = value; }
        }
        public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }
        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }
        public virtual int TempoTrabalho() // A palavra virtual quer dizer que as sub classes podem sobescrever sobre esse TempoTrabalho, ou seja se alguma sub classe usar o TempoTrabalho como uma nova o objeto iria realizar o que está na sub classe 
        {
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);
            return (span.Days);
        }

        public abstract double SalarioBruto();// Um método abstarto significa que eu n preciso colocar o código, ou seja, a classe é abstrata e não posso criar objetos a partir dela
    }
}
