﻿namespace Pclasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            txtMatricula = new TextBox();
            txtNome = new TextBox();
            txtHora = new TextBox();
            txtSalario = new TextBox();
            txtFalta = new TextBox();
            txtData = new TextBox();
            btnInstanciar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 18);
            label1.Name = "label1";
            label1.Size = new Size(57, 15);
            label1.TabIndex = 0;
            label1.Text = "Matrícula";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(1, 45);
            label2.Name = "label2";
            label2.Size = new Size(40, 15);
            label2.TabIndex = 1;
            label2.Text = "Nome";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(7, 78);
            label3.Name = "label3";
            label3.Size = new Size(97, 15);
            label3.TabIndex = 2;
            label3.Text = "Salário por Horas";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(7, 107);
            label4.Name = "label4";
            label4.Size = new Size(101, 15);
            label4.TabIndex = 3;
            label4.Text = "Número de Horas";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(9, 145);
            label5.Name = "label5";
            label5.Size = new Size(138, 15);
            label5.TabIndex = 4;
            label5.Text = "Data Entrada na Empresa";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(9, 190);
            label6.Name = "label6";
            label6.Size = new Size(78, 15);
            label6.TabIndex = 5;
            label6.Text = "Dias de Faltas";
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(68, 10);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(100, 23);
            txtMatricula.TabIndex = 1;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(47, 42);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(100, 23);
            txtNome.TabIndex = 2;
            // 
            // txtHora
            // 
            txtHora.Location = new Point(114, 107);
            txtHora.Name = "txtHora";
            txtHora.Size = new Size(112, 23);
            txtHora.TabIndex = 4;
            // 
            // txtSalario
            // 
            txtSalario.Location = new Point(110, 75);
            txtSalario.Name = "txtSalario";
            txtSalario.Size = new Size(100, 23);
            txtSalario.TabIndex = 3;
            // 
            // txtFalta
            // 
            txtFalta.Location = new Point(93, 187);
            txtFalta.Name = "txtFalta";
            txtFalta.Size = new Size(100, 23);
            txtFalta.TabIndex = 6;
            // 
            // txtData
            // 
            txtData.Location = new Point(153, 142);
            txtData.Name = "txtData";
            txtData.Size = new Size(100, 23);
            txtData.TabIndex = 5;
            // 
            // btnInstanciar
            // 
            btnInstanciar.Location = new Point(311, 239);
            btnInstanciar.Name = "btnInstanciar";
            btnInstanciar.Size = new Size(150, 60);
            btnInstanciar.TabIndex = 12;
            btnInstanciar.Text = "Instanciar Horista";
            btnInstanciar.UseVisualStyleBackColor = true;
            btnInstanciar.Click += btnInstanciar_Click;
            // 
            // frmHorista
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnInstanciar);
            Controls.Add(txtData);
            Controls.Add(txtFalta);
            Controls.Add(txtSalario);
            Controls.Add(txtHora);
            Controls.Add(txtNome);
            Controls.Add(txtMatricula);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmHorista";
            Text = "frmHorista";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox txtMatricula;
        private TextBox txtNome;
        private TextBox txtHora;
        private TextBox txtSalario;
        private TextBox txtFalta;
        private TextBox txtData;
        private Button btnInstanciar;
    }
}