﻿namespace PFormatacao
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnString = new System.Windows.Forms.Button();
            this.btnValores = new System.Windows.Forms.Button();
            this.btnDateTime = new System.Windows.Forms.Button();
            this.btnFormat = new System.Windows.Forms.Button();
            this.btnOperacoes = new System.Windows.Forms.Button();
            this.btnFormatVal = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.SuspendLayout();
            // 
            // btnString
            // 
            this.btnString.Location = new System.Drawing.Point(153, 41);
            this.btnString.Name = "btnString";
            this.btnString.Size = new System.Drawing.Size(104, 64);
            this.btnString.TabIndex = 0;
            this.btnString.Text = "TOString-Datas";
            this.btnString.UseVisualStyleBackColor = true;
            this.btnString.Click += new System.EventHandler(this.btnString_Click);
            // 
            // btnValores
            // 
            this.btnValores.Location = new System.Drawing.Point(318, 41);
            this.btnValores.Name = "btnValores";
            this.btnValores.Size = new System.Drawing.Size(100, 64);
            this.btnValores.TabIndex = 1;
            this.btnValores.Text = "TOString-Valores";
            this.btnValores.UseVisualStyleBackColor = true;
            this.btnValores.Click += new System.EventHandler(this.btnValores_Click);
            // 
            // btnDateTime
            // 
            this.btnDateTime.Location = new System.Drawing.Point(471, 41);
            this.btnDateTime.Name = "btnDateTime";
            this.btnDateTime.Size = new System.Drawing.Size(101, 64);
            this.btnDateTime.TabIndex = 2;
            this.btnDateTime.Text = "Metodo Date time";
            this.btnDateTime.UseVisualStyleBackColor = true;
            this.btnDateTime.Click += new System.EventHandler(this.btnDateTime_Click);
            // 
            // btnFormat
            // 
            this.btnFormat.Location = new System.Drawing.Point(153, 154);
            this.btnFormat.Name = "btnFormat";
            this.btnFormat.Size = new System.Drawing.Size(104, 66);
            this.btnFormat.TabIndex = 3;
            this.btnFormat.Text = "String Format - Datas";
            this.btnFormat.UseVisualStyleBackColor = true;
            this.btnFormat.Click += new System.EventHandler(this.btnFormat_Click);
            // 
            // btnOperacoes
            // 
            this.btnOperacoes.Location = new System.Drawing.Point(471, 154);
            this.btnOperacoes.Name = "btnOperacoes";
            this.btnOperacoes.Size = new System.Drawing.Size(101, 66);
            this.btnOperacoes.TabIndex = 4;
            this.btnOperacoes.Text = "Operações com Datas";
            this.btnOperacoes.UseVisualStyleBackColor = true;
            this.btnOperacoes.Click += new System.EventHandler(this.btnOperacoes_Click);
            // 
            // btnFormatVal
            // 
            this.btnFormatVal.Location = new System.Drawing.Point(318, 154);
            this.btnFormatVal.Name = "btnFormatVal";
            this.btnFormatVal.Size = new System.Drawing.Size(100, 66);
            this.btnFormatVal.TabIndex = 5;
            this.btnFormatVal.Text = "String Format -Valores";
            this.btnFormatVal.UseVisualStyleBackColor = true;
            this.btnFormatVal.Click += new System.EventHandler(this.btnFormatVal_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "dd/MM/yyy";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(47, 308);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(228, 20);
            this.dateTimePicker1.TabIndex = 6;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(370, 256);
            this.monthCalendar1.MinDate = new System.DateTime(1980, 1, 1, 0, 0, 0, 0);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 7;
            this.monthCalendar1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.btnFormatVal);
            this.Controls.Add(this.btnOperacoes);
            this.Controls.Add(this.btnFormat);
            this.Controls.Add(this.btnDateTime);
            this.Controls.Add(this.btnValores);
            this.Controls.Add(this.btnString);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnString;
        private System.Windows.Forms.Button btnValores;
        private System.Windows.Forms.Button btnDateTime;
        private System.Windows.Forms.Button btnFormat;
        private System.Windows.Forms.Button btnOperacoes;
        private System.Windows.Forms.Button btnFormatVal;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
    }
}

