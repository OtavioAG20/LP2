﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PNotebook01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] precos = new double[3, 3];
            double auxilio;
            double media;
            double total = 0;
            for (int notebook = 0; notebook < 3; notebook++)
            {
                auxilio = 0;
                media = 0;
                for (int loja = 0; loja < 3; loja++)
                {
                    string auxiliar = Interaction.InputBox($"Digite o preço do {notebook + 1}° notebook da {loja + 1}° loja");
                    if (!double.TryParse(auxiliar, out precos[notebook, loja]))
                    {
                        MessageBox.Show("Número digitado inválido");
                        loja--;
                    }
                    else
                     if (precos[notebook, loja] < 0)
                    {
                        MessageBox.Show("Número digitado inváido, digite o preço real do produto!");
                        loja--;
                    }
                    if(precos[notebook, loja] >=0)
                    {
                        auxilio = auxilio + precos[notebook, loja];
                        listBxMostrar.Items.Add($"Notebook {notebook + 1} loja {loja + 1} R${precos[notebook, loja]}");
                        total = total + precos[notebook, loja];

                    }   
                }
                media = auxilio / 3;
                listBxMostrar.Items.Add("A média da loja foi de" + media.ToString("F2"));
            }
            total = total / 3;
            listBxMostrar.Items.Add(" A média total foi dos computadores foi de" + total.ToString("F2"));
        }
    }
}
