﻿namespace PtesteMetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            lblPalavra1 = new Label();
            lblPalavra2 = new Label();
            btnCompara = new Button();
            btnInserir1 = new Button();
            btnInserir2 = new Button();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Location = new Point(82, 12);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(82, 54);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 1;
            // 
            // lblPalavra1
            // 
            lblPalavra1.AutoSize = true;
            lblPalavra1.Location = new Point(14, 18);
            lblPalavra1.Name = "lblPalavra1";
            lblPalavra1.Size = new Size(54, 15);
            lblPalavra1.TabIndex = 2;
            lblPalavra1.Text = "Palavra 1";
            // 
            // lblPalavra2
            // 
            lblPalavra2.AutoSize = true;
            lblPalavra2.Location = new Point(12, 57);
            lblPalavra2.Name = "lblPalavra2";
            lblPalavra2.Size = new Size(54, 15);
            lblPalavra2.TabIndex = 3;
            lblPalavra2.Text = "Palavra 2";
            // 
            // btnCompara
            // 
            btnCompara.Location = new Point(42, 159);
            btnCompara.Name = "btnCompara";
            btnCompara.Size = new Size(140, 60);
            btnCompara.TabIndex = 4;
            btnCompara.Text = "Comparação";
            btnCompara.UseVisualStyleBackColor = true;
            // 
            // btnInserir1
            // 
            btnInserir1.Location = new Point(211, 159);
            btnInserir1.Name = "btnInserir1";
            btnInserir1.Size = new Size(136, 60);
            btnInserir1.TabIndex = 5;
            btnInserir1.Text = "Inserior  1° no meio do 2°";
            btnInserir1.UseVisualStyleBackColor = true;
            // 
            // btnInserir2
            // 
            btnInserir2.Location = new Point(366, 159);
            btnInserir2.Name = "btnInserir2";
            btnInserir2.Size = new Size(140, 60);
            btnInserir2.TabIndex = 6;
            btnInserir2.Text = "Inserir ** no meio do 1°";
            btnInserir2.UseVisualStyleBackColor = true;
            // 
            // frmExercicio2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnInserir2);
            Controls.Add(btnInserir1);
            Controls.Add(btnCompara);
            Controls.Add(lblPalavra2);
            Controls.Add(lblPalavra1);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Name = "frmExercicio2";
            Text = "frmExercicio2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private TextBox textBox2;
        private Label lblPalavra1;
        private Label lblPalavra2;
        private Button btnCompara;
        private Button btnInserir1;
        private Button btnInserir2;
    }
}