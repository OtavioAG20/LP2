﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumeros_Click(object sender, EventArgs e)
        {
            int c = 0;
            int contNum = 0;

            while (c < rchtxtFrase.Text.Length)
            {
                if (Char.IsNumber(rchtxtFrase.Text[c]))
                {
                    contNum++;
                }
                c++; ;
            }
            MessageBox.Show("O texto tem " + contNum);

        }

        private void btnPosicao_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }
            }
            MessageBox.Show($"A posição do 1° caracter em branco é {posicao}");
        }

        private void btnLetra_Click(object sender, EventArgs e)
        {
            int contletra = 0;

            foreach(char c in rchtxtFrase.Text)
            {
                if(char.IsLetter(c))
                {
                    contletra++;
                }
            }
            MessageBox.Show($"O texto tem {contletra} letras");
        }
    }
}
