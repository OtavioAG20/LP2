﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            int Num1 = 0;
            int Num2 = 0;
            if(!int.TryParse(txtNumero1.Text, out Num1) || !int.TryParse(txtNumero2.Text, out Num2) || Num1> Num2)
            {
                MessageBox.Show("Número inválido");
                txtNumero1.Focus();
            }
            else
            {
                Random obj1 = new Random();
                int x = obj1.Next(Num1, Num2);
                MessageBox.Show($"N° sorteado foi {x}");
            }
        }
    }
}
