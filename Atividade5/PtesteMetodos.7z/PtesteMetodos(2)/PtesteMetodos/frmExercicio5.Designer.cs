﻿namespace PtesteMetodos
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNumero1 = new Label();
            lblNumero2 = new Label();
            txtNumero1 = new TextBox();
            txtNumero2 = new TextBox();
            btnSorteio = new Button();
            SuspendLayout();
            // 
            // lblNumero1
            // 
            lblNumero1.AutoSize = true;
            lblNumero1.Location = new Point(12, 25);
            lblNumero1.Name = "lblNumero1";
            lblNumero1.Size = new Size(75, 20);
            lblNumero1.TabIndex = 0;
            lblNumero1.Text = "Número 1";
            // 
            // lblNumero2
            // 
            lblNumero2.AutoSize = true;
            lblNumero2.Location = new Point(12, 66);
            lblNumero2.Name = "lblNumero2";
            lblNumero2.Size = new Size(75, 20);
            lblNumero2.TabIndex = 1;
            lblNumero2.Text = "Número 2";
            // 
            // txtNumero1
            // 
            txtNumero1.Location = new Point(93, 22);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(125, 27);
            txtNumero1.TabIndex = 2;
            // 
            // txtNumero2
            // 
            txtNumero2.Location = new Point(93, 66);
            txtNumero2.Name = "txtNumero2";
            txtNumero2.Size = new Size(125, 27);
            txtNumero2.TabIndex = 3;
            // 
            // btnSorteio
            // 
            btnSorteio.Location = new Point(204, 142);
            btnSorteio.Name = "btnSorteio";
            btnSorteio.Size = new Size(173, 77);
            btnSorteio.TabIndex = 4;
            btnSorteio.Text = "Sorteio";
            btnSorteio.UseVisualStyleBackColor = true;
            btnSorteio.Click += btnSorteio_Click;
            // 
            // frmExercicio5
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnSorteio);
            Controls.Add(txtNumero2);
            Controls.Add(txtNumero1);
            Controls.Add(lblNumero2);
            Controls.Add(lblNumero1);
            Name = "frmExercicio5";
            Text = "frmExercicio5";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNumero1;
        private Label lblNumero2;
        private TextBox txtNumero1;
        private TextBox txtNumero2;
        private Button btnSorteio;
    }
}