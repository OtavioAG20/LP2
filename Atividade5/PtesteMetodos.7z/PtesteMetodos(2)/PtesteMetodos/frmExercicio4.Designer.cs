﻿namespace PtesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rchtxtFrase = new RichTextBox();
            btnPosicao = new Button();
            btnLetra = new Button();
            btnNumeros = new Button();
            SuspendLayout();
            // 
            // rchtxtFrase
            // 
            rchtxtFrase.Location = new Point(294, 63);
            rchtxtFrase.Margin = new Padding(3, 4, 3, 4);
            rchtxtFrase.Name = "rchtxtFrase";
            rchtxtFrase.Size = new Size(252, 187);
            rchtxtFrase.TabIndex = 0;
            rchtxtFrase.Text = "";
            // 
            // btnPosicao
            // 
            btnPosicao.Location = new Point(350, 308);
            btnPosicao.Margin = new Padding(3, 4, 3, 4);
            btnPosicao.Name = "btnPosicao";
            btnPosicao.Size = new Size(102, 76);
            btnPosicao.TabIndex = 1;
            btnPosicao.Text = "Posição 1° Carcter Branco";
            btnPosicao.UseVisualStyleBackColor = true;
            btnPosicao.Click += btnPosicao_Click;
            // 
            // btnLetra
            // 
            btnLetra.Location = new Point(511, 308);
            btnLetra.Margin = new Padding(3, 4, 3, 4);
            btnLetra.Name = "btnLetra";
            btnLetra.Size = new Size(98, 76);
            btnLetra.TabIndex = 2;
            btnLetra.Text = "Contar Letras";
            btnLetra.UseVisualStyleBackColor = true;
            btnLetra.Click += btnLetra_Click;
            // 
            // btnNumeros
            // 
            btnNumeros.Location = new Point(201, 308);
            btnNumeros.Margin = new Padding(3, 4, 3, 4);
            btnNumeros.Name = "btnNumeros";
            btnNumeros.Size = new Size(102, 76);
            btnNumeros.TabIndex = 3;
            btnNumeros.Text = "Contar Números";
            btnNumeros.UseVisualStyleBackColor = true;
            btnNumeros.Click += btnNumeros_Click;
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(914, 600);
            Controls.Add(btnNumeros);
            Controls.Add(btnLetra);
            Controls.Add(btnPosicao);
            Controls.Add(rchtxtFrase);
            Margin = new Padding(3, 4, 3, 4);
            Name = "frmExercicio4";
            Text = "frmExercicio4";
            ResumeLayout(false);
        }

        #endregion

        private RichTextBox rchtxtFrase;
        private Button btnPosicao;
        private Button btnLetra;
        private Button btnNumeros;
    }
}