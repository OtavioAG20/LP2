﻿namespace PtesteMetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtPalavra1 = new TextBox();
            txtPalavra2 = new TextBox();
            btnRemover = new Button();
            btnInverter = new Button();
            lblPalavra1 = new Label();
            lblPalvra2 = new Label();
            SuspendLayout();
            // 
            // txtPalavra1
            // 
            txtPalavra1.Location = new Point(121, 21);
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(100, 23);
            txtPalavra1.TabIndex = 0;
            // 
            // txtPalavra2
            // 
            txtPalavra2.Location = new Point(121, 64);
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(100, 23);
            txtPalavra2.TabIndex = 1;
            // 
            // btnRemover
            // 
            btnRemover.Location = new Point(106, 148);
            btnRemover.Name = "btnRemover";
            btnRemover.Size = new Size(89, 45);
            btnRemover.TabIndex = 2;
            btnRemover.Text = " Remover o 1° do 2°";
            btnRemover.UseVisualStyleBackColor = true;
            btnRemover.Click += btnRemover_Click;
            // 
            // btnInverter
            // 
            btnInverter.Location = new Point(233, 148);
            btnInverter.Name = "btnInverter";
            btnInverter.Size = new Size(89, 45);
            btnInverter.TabIndex = 3;
            btnInverter.Text = "Inverter 1°";
            btnInverter.UseVisualStyleBackColor = true;
            btnInverter.Click += btnInverter_Click;
            // 
            // lblPalavra1
            // 
            lblPalavra1.AutoSize = true;
            lblPalavra1.Location = new Point(61, 24);
            lblPalavra1.Name = "lblPalavra1";
            lblPalavra1.Size = new Size(54, 15);
            lblPalavra1.TabIndex = 4;
            lblPalavra1.Text = "Palavra 1";
            // 
            // lblPalvra2
            // 
            lblPalvra2.AutoSize = true;
            lblPalvra2.Location = new Point(61, 67);
            lblPalvra2.Name = "lblPalvra2";
            lblPalvra2.Size = new Size(54, 15);
            lblPalvra2.TabIndex = 5;
            lblPalvra2.Text = "Palavra 2";
            // 
            // frmExercicio3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblPalvra2);
            Controls.Add(lblPalavra1);
            Controls.Add(btnInverter);
            Controls.Add(btnRemover);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Name = "frmExercicio3";
            Text = "frmExercicio3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtPalavra1;
        private TextBox txtPalavra2;
        private Button btnRemover;
        private Button btnInverter;
        private Label lblPalavra1;
        private Label lblPalvra2;
    }
}