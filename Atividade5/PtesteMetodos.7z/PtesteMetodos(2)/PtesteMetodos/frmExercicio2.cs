﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCompara_Click(object sender, EventArgs e)
        {
            if (string.Compare(txtPalavra1.Text, txtPalavra2.Text, true) == 0)
            {
                MessageBox.Show("As palavras são iguais");
            }
            else
            {
                MessageBox.Show("As palavras são diferentes");
            }
        }

        private void btnInserir1_Click(object sender, EventArgs e)
        {
            string palavra;
            string palavra2 = txtPalavra1.Text;
            int metade = txtPalavra2.TextLength / 2;
            palavra = txtPalavra2.Text.Substring(0, metade);
            txtPalavra2.Text = palavra + palavra2 + txtPalavra2.Text.Substring(metade);

        }

        private void btnInserir2_Click(object sender, EventArgs e)
        {
            string palavra = "**";
            int metade = txtPalavra1.TextLength / 2;
            txtPalavra2.Text = txtPalavra1.Text.Insert(metade, palavra);
        }
    }
}
